app.controller('suscritascontroller', ['$scope',
    function ($scope) {
        $scope.titulo="Lista Suscrito"
    }]);