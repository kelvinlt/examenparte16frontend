app.controller('buscarcontroller', ['$scope',
    function ($scope) {
        $scope.titulo="Buscar"
    }]);