app.controller('listacompracontroller', ['$scope',
    function ($scope) {
        $scope.titulo="Lista de la Compra"
    }]);