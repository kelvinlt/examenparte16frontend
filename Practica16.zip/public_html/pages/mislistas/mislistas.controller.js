app.controller('mislistascontroller', ['$scope',
    function ($scope) {
        $scope.titulo="Mis Listas"
    }]);